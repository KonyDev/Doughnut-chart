define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Browser_e82c7f6d6c914ba699a8d3111cfd966a: function AS_Browser_e82c7f6d6c914ba699a8d3111cfd966a(eventobject, params) {
        var self = this;
        this.myPostShow();
    }
});